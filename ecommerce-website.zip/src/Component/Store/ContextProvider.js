import React, { createContext, useState ,useEffect} from "react";
import axios from "axios";

const CartContext = createContext();


const ContextProvider = (props) => {
    const userEmail = localStorage.getItem('email')
    const [cartItems, setCartItems] = useState([]);
    const [cartItemCount, setCartItemCount] = useState(0);
    const [user, setUser] = useState(null);

  //  get // 

  const getCartItems = async () => {
    try {
      if (!userEmail) {
        console.error("User not logged in. Unable to retrieve cart items.");
        return;
      }

      const response = await axios.get(
        `https://crudcrud.com/api/e07a8f4c42c04e579e51e1c9dbfc4705/carts`
      );

      const retrievedCartItems = response.data;
      
      setCartItems(retrievedCartItems);
    } catch (error) {
      // Handle error
      console.log("Error retrieving cart items:", error);
    }
  };

  useEffect(() => {
    // Call getCartItems inside useEffect when component mounts
    getCartItems();
  }, []);

 
  const findProductIndex = (title) => {
    return cartItems.findIndex((item) => item.title === title);
  };

  const addItemToCart = async (item) => {
    try {
      if (!userEmail) {
        console.log("User not logged in. Please log in to add items to the cart");
        return;
      }
  
      const productIndex = findProductIndex(item.title);
  
      if (productIndex !== -1) {
        // Item already exists, update quantity
        const updatedCartItems = [...cartItems];
        updatedCartItems[productIndex].quantity =+1;
        // console.log("updatedCartItems[productIndex].quantity",updatedCartItems[productIndex],"itemquan", cartItems);
      setCartItems(updatedCartItems);
        
        // setCartItems(updatedCart);

      } else {
        // Item doesn't exist, add to cart
        setCartItems((prevItems) => [...prevItems, { ...item, quantity: 1 }]);
      }
  
      setCartItemCount((prevCount) => prevCount + 1);
  
      // Fetch the updated cart items after the local state has been updated
      await getCartItems();
  
      // Now, post the updated cart data to the server
      const productWithUser = {
        ...item,
        quantity:1,
        userEmail: userEmail.replace(/[@.]/g, ""),
      };
  
      await axios.post(
        `https://crudcrud.com/api/e07a8f4c42c04e579e51e1c9dbfc4705/carts`,
        productWithUser
      );
    } catch (error) {
      console.error("Error adding product to cart:", error);
    }
  };
  

   
  const removeItemFromCart = async (_id) => {
    const itemToRemove = cartItems.find((item) => item._id === _id);
    

    if (!itemToRemove) {
      console.error("Item to remove is undefined.");
      return;
    }

    // Update local state
     setCartItems((prevItems) => prevItems.filter((item) => item._id !== _id));

  setCartItemCount((prevCount) => prevCount - 1);//  console.log(itemToRemove.id);
    try {
    //   if (!user) {
    //     console.error("User not logged in. Unable to remove item from cart.");
    //     return;
    //   }

    //   const userEmail = userEmail.replace(/[@.]/g, '');

      // Send DELETE request to remove item from the server
      await axios.delete(
        `https://crudcrud.com/api/e07a8f4c42c04e579e51e1c9dbfc4705/carts/${_id}`
      );
      
      // await getCartItems();
      console.log("Item removed from cart on the server.");
    } catch (error) {
      // Handle error
      console.error("Error removing item from cart:", error);
    }
  };

  
  // console.log(cartItems);

    const clearCart = () => {
        setCartItems([]);
        setCartItemCount(0);
    };

    const loginUser = (userData) => {
        setUser(userData);
        console.log(userData);
      };

      const logoutUser = () => {
        setUser(null);
      };
    
      const increaseQuantity = (_id) => {
        setCartItems((prevItems) =>
          prevItems.map((item) =>
            item._id === _id ? { ...item, quantity: item.quantity + 1 } : item
          )
        );
      };
    
      const decreaseQuantity = (_id) => {
        setCartItems((prevItems) =>
          prevItems.map((item) =>
            item._id === _id ? { ...item, quantity: Math.max(item.quantity - 1, 0) } : item
          )
        );
      };

    return (
        <CartContext.Provider value={{
            cartItems,
            addItemToCart,
            removeItemFromCart,
            clearCart,
            cartItemCount,
            user,
            loginUser,
            logoutUser,
            increaseQuantity,
            decreaseQuantity,
        }}>
            {props.children}
        </CartContext.Provider>
    )
}
export {ContextProvider, CartContext};